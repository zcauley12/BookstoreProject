package com.bookstore;

public class Book {
    private String ISBN;
    private String category;
    private String authorName;
    private String bookTitle;
    private int edition;
    private String publisher;
    private int publicationYear;
    private int quantityInStock;
    private int price;

    public int getPrice() {
        return price;
    }

    public int getStock() {
        return quantityInStock;
    }

    public String getInfo() {
        return null;
    }
}
