package com.bookstore;

public class Order {
    private int orderNumber;
    private int orderTotal;

    public int getOrderNumber() {
        return orderNumber;
    }

    public int getOrderTotal() {
        return orderTotal;
    }
}
