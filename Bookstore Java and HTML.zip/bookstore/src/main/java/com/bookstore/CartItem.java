package com.bookstore;

public class CartItem {
    private int quantity;

    public int getQuantity() {
        return quantity;
    }
}
