package com.bookstore;

public abstract class User {
    private String firstName;
    private String lastName;
    private String password;
    private String email;
    private String address;
    private int zipCode;
    private String city;
    private int cardNumber;
    private int cvv;
    private String expirationDate;

    public User() {

    }

    public void changePassword() {

    }

    public void resetPassword() {

    }

    public void editProfile() {

    }

    public boolean login(String username, String password) {
        return false;
    }

    public String getName() {
        return firstName + " " + lastName;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }
}
