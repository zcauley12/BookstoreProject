package com.bookstore;

public class Cart {
    private int itemCount;

    public int getItemCount() {
        return itemCount;
    }
}
