package com.bookstore;

public class Admin extends User {
    private int empNumber;

    public Admin() {
        empNumber = 0;
    }

    public void addBook() {

    }

    public int getEmpNo() {
        return empNumber;
    }
}
