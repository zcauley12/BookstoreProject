package com.bookstore;

public enum Status {
    ACTIVE,
    INACTIVE
}
