package com.bookstore;

public class Promo {
    private int PromoID;
    private double percentOff;

    public double getPercent() {
        return percentOff;
    }
}
