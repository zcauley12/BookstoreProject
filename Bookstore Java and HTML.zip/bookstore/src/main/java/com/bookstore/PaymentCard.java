package com.bookstore;

public class PaymentCard {
    private int cardNumber;
    private String expirationDate;

    public int getCardNo() {
        return cardNumber;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

}
