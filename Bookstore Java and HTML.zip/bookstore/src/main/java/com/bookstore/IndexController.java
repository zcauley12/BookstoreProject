package com.bookstore;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class IndexController {
    @RequestMapping("/addbook")
    public String addBook() {
        return "AddBook.html";
    }

    @RequestMapping("/admin")
    public String admin() {
        return "AdminHomepage.html";
    }

    @RequestMapping("/adminsearch")
    public String adminSearch() {
        return "AdminSearch.html";
    }

    @RequestMapping("/search")
    public String search() {
        return "SearchView.html";
    }

    @RequestMapping("/bookdetails")
    public String bookDetails() {
        return "BookDetails.html";
    }

    @RequestMapping("/cart")
    public String cart() {
        return "Cart.html";
    }

    @RequestMapping("/orderconfirmation")
    public String orderConfirmation() {
        return "OrderConfirmation.html";
    }

    @RequestMapping("/orderhistory")
    public String orderHistory() {
        return "OrderHistory.html";
    }

    @RequestMapping("/profile")
    public String editProfile() {
        return "EditProfile.html";
    }

    @RequestMapping("/changepassword")
    public String changePassword() {
        return "ChangePassword.html";
    }

    @RequestMapping("/billingdetails")
    public String billingDetails() {
        return "BillingDetails.html";
    }

    @RequestMapping("/paymentinfo")
    public String paymentInfo() {
        return "PaymentInfo.html";
    }

    @RequestMapping("/personalinfo")
    public String personalInfo() {
        return "PersonalInfo.html";
    }

    @RequestMapping("/updateaddress")
    public String updateAddress() {
        return "updateAddress.html";
    }

    @RequestMapping("/updatepaymentinfo")
    public String updatePaymentInfo() {
        return "updatePaymentInfo.html";
    }

    @RequestMapping("/")
    public String homepage() {
        return "Homepage.html";
    }

    @RequestMapping("/login")
    public String login() {
        return "Login.html";
    }

    @GetMapping("/registration")
    public String registration(Model model) {
        model.addAttribute("customer", new Customer());
        return "Registration.html";
    }

    @PostMapping("/registration")
    public String verifyEmail(@ModelAttribute Customer customer, Model model) {
        model.addAttribute("customer", customer);
        return "RegistrationConfirmation.html";
    }

    @RequestMapping("/confirmation")
    public String confirmation() {
        return "EmailConfirmation.html";
    }

}
