package com.bookstore;

public class BookCopy {
    private int bookID;

    public int getID() {
        return bookID;
    }
}
