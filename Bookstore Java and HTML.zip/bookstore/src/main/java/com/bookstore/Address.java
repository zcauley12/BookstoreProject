package com.bookstore;

public class Address {
    private String street;
    private String city;
    private String state;
    private int zipcode;

    public String getAddress() {
        return street + ", " + city + " " + state + " "  + zipcode;
    }
}
