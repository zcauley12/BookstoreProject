package com.bookstore;

/*import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;*/

public class Customer extends User {
    private Status type;
    private int accountID;

    public Customer() {
        type = Status.INACTIVE;
        accountID = 0;
    }

    /*public void sendMail(){
        Properties properties = new Properties();
        Session session = Session.getDefaultInstance(properties, null)
        MimeMessage message = new MimeMessage(session);
        message.addRecipient(Message.RecipientType.TO, new InternetAddress("example@gmail.com"));
        message.setHeader("Hi, everyone");
        message.setText("Hi, This mail is to inform you...");
    }*/

    public void enterPaymentInfo() {

    }

    public void searchCatalog() {

    }

    public void addBookToCart() {

    }

    public void removeBookFromCart() {

    }

    public void checkout() {

    }

    public void applyPromotion() {

    }

    public void viewOrderHistory() {

    }

    public void reorderBook() {

    }

    public void returnBook() {

    }

    public Status getStatus() {
        return type;
    }
}
